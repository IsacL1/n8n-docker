﻿Endpoint Secure Agent Installation in Linux Operating System
Download Installation Package
1. Download installer 
	a. Download by executing the following command
	    wget --no-check-certificate https://%mgrdcip%:4430/download_installer_linux.php -O linux_aes_installer.tar.gz && tar -xzvf linux_aes_installer.tar.gz && ./agent_installer.sh -c
	b. Download from login page or System > Client Enforcement page in Endpoint Secure manager.
2. Decompress the installer: tar -xzvf linux_aes_installer.tar.gz
3. Execute the command: ./agent_installer.sh
	a. Default Installation (Used when manager_info.txt exists in the same directory )
                                ./agent_installer.sh
	b. Custom Installation (Domain name, port and path can be specified and combined as per your needs) 
                                ./agent_installer.sh -f
		./agent_installer.sh -h www.mgr.com
		./agent_installer.sh -h www.mgr.com -p 443 -d /root/edr/ -f
                                Parameters:
			-h host       Specify domain name, IP address
			-p port       Specify port
			-d dir        Specify installation path (absolute path)
			-f            Enforce installation
			-o:           Indicates that the installation process of the full agent installer will be executed.
			-u            Refers to the Customer ID. This is only applicable to Sangfor Access-Endpoint Secure.
			--help        Show Help document
4. Installation completed, and Endpoint Secure Agent will connect to Endpoint Secure Manager automatically.